package com.ucad.kital.raph.gestionProduit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionProduitApplicationTests {

	@Test
	void contextLoads() {
	}

}
